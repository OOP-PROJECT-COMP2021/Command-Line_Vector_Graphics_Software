# Command Line Vector Graphics Software
## COMP2021 Object-Oriented Programming (2021) - Project Group 1
## Source code and tests

ZHANG Wengyu 21098431d

XU Le 21096101d

CHEN Derun 21098424d

YE Haowen 21098829d

> Run **Application** class first,
> 
> Then enter **0** to launch Clevis 
> 
> or enter **1** to launch the GUI

> The _**test**_ file includes all tests with line coverage of 98% in total