package hk.edu.polyu.comp.comp2021.clevis.model;

/** interface deque */
public interface Deque<T> {
    /** add last
     * @param item : item */
    void addLast(T item);
}
